@extends('client.client')


@section('title', 'Trang đăng nhập')
@section('description', '')
@section('content')
    <div class="container d-flex justify-content-center align-item-center">

        <h1>Trang chủ</h1>

    </div>
@endsection
