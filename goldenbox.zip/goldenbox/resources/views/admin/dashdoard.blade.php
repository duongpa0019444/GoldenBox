@extends('admin.admin')


@section('title', 'Trang admin')
@section('description', '')
@section('content')
<div class="container d-flex justify-content-center align-item-center">

    <h1>Trang dashboard</h1>
</div>
@endsection
