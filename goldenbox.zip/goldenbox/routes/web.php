<?php

use App\Http\Controllers\admin\dashboardController;
use App\Http\Controllers\client\loginController;
use App\Http\Middleware\AuthAdmin;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('client.home');
})->name('home');

Route::get('admin', function () {
    return view('client.login');
});
Route::post('login', [loginController::class, 'login'])->name('admin.login');


Route::middleware(['auth', AuthAdmin::class])->group(function() {
    Route::get('admin/dashboard', [dashboardController::class, 'dashBoard'])->name('admin.dashboard');
});
