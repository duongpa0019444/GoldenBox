<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class chi_tiet_anh extends Model
{
    //
}
