<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class danh_mucs extends Model
{
    protected $fillable = [
        'ten_danh_muc_vi',
        'ten_danh_muc_en',
    ];
}
