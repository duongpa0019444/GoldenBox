<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
</head>
<body>
    <header>Header</header>
    <?php echo $__env->yieldContent('content'); ?>
    <footer>footer</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldenbox\resources\views/client/client.blade.php ENDPATH**/ ?>