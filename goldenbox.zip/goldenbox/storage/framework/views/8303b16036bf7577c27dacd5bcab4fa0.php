<?php $__env->startSection('title', 'Trang đăng nhập'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center align-item-center">

        <h1>Trang chủ</h1>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\GOLDEN_BOX\goldenbox\resources\views/client/home.blade.php ENDPATH**/ ?>