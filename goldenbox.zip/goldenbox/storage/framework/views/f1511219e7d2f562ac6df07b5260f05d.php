<div class="container d-flex justify-content-center align-item-center">

        <form action="" method="post" enctype="multipart/form-data" class="col-lg-6 col-md-12">
            <h2 class="text-center">Đăng Nhập</h2>
          <div class="mb-3">
            <label class="form-label">Tên đăng nhập</label>
            <input type="text" class="form-control" name="">
          </div>

          <div class="mb-3">
            <label class="form-label">Mật khẩu</label>
            <input type="text" class="form-control" name="">
          </div>

          <button type="submit" class="btn btn-primary">Đăng Nhập</button>
        </form>

</div>
<?php /**PATH C:\xampp\htdocs\goldenbox\resources\views/login.blade.php ENDPATH**/ ?>