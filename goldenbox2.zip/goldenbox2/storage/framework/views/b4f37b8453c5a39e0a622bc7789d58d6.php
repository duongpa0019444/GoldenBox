

<?php $__env->startSection('title', 'Sửa Danh Mục'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content">

    <!-- Start Container Fluid -->
    <div class="container-xxl">

         <div class="row">
            
              <div class="col-xl-12 col-lg-8 ">
                    <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="post" id="formCategory"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">General Information</h4>
                                </div>
                                <div id="uploaded-files3"></div>
                                <div class="card-body">
                                    <div class="row">
                                        <label for="product-name" class="form-label">Category</label>
                                             <div class="col-lg-6">       
                                                  <input type="text" id="category-name mb-1" name="ten_danh_muc_vi" class="form-control mb-2" placeholder="Tên danh mục" value="<?php echo e($category->ten_danh_muc_vi); ?>">   
                                                  <?php $__errorArgs = ['ten_danh_muc_vi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                      
                                             </div>
                                             
                                             <div class="col-lg-6">
                                                  <input type="text" id="category-name" name="ten_danh_muc_en" class="form-control mb-2" placeholder="Tên danh mục English" value="<?php echo e($category->ten_danh_muc_en); ?>">
                                                  
                                             </div>
                                   </div>
                                   <div class="row">
                                             <div class="col-lg-6">
                                                  <div class="mb-3">
                                                       <label for="category-name" class="form-label mt-1">Slug</label>
                                                       <input type="text" id="category-name" name="slug" class="form-control" placeholder="slug" value="<?php echo e($category->slug); ?>">
                                                  </div>
                                             </div>
                                   </div>    
                              </div>
                        </div>
                        <div class="p-3 bg-light mb-3 rounded">
                            <div class="row justify-content-end g-2">
                                 <div class="col-lg-2">
                                  <button type="button" class="btn btn-outline-secondary w-100" onclick="resetForm()">Reset</button>
                                 </div>
                                 <div class="col-lg-2">
                                      <button type="submit" class="btn btn-primary w-100">Save</button>
                                 </div>
                            </div>
                             <?php if(session('success')): ?>
                             <div class="alert alert-success">
                             <?php echo e(session('success')); ?>

                             </div>
                             <?php endif; ?>
    
                             
                             <?php if(session('error')): ?>
                             <div class="alert alert-danger">
                             <?php echo e(session('error')); ?>

                             </div>
                             <?php endif; ?>
                             <?php if($errors->any()): ?>
                             <div class="alert alert-danger">
                                  <ul class="mb-0">
                                       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </ul>
                              </div>
                             <?php endif; ?>
                       </div>
                    </form>
              </div>
         </div>

    </div>
    <!-- End Container Fluid -->

</div>
<script>
     function resetForm() {
         document.getElementById('formCategory').reset();
     }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\goldenbox\goldenbox2\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>