

<?php $__env->startSection('title', 'Trang admin'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('content'); ?>
<style>
    .ck-editor__editable {
        min-height: 300px !important;
        border-radius: 0.375rem !important;
    }
</style>

<div class="page-content">
    <div class="container-xxl">
        <form method="POST" action="<?php echo e(route('admin.products.update', $product->id)); ?>" enctype="multipart/form-data" id="productForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <!-- Left Column -->
                <div class="col-xl-3 col-lg-4">
                    <div class="card">
                        <div class="card-body">
                            <label for="fileInput" style="cursor: pointer;">
                                <img id="previewImage" src="<?php echo e(asset('admin/images/products/' . $product->anh_chinh)); ?>" alt="Ảnh sản phẩm" class="img-fluid rounded bg-light" style="width: 100%; object-fit: cover;">
                            </label>
                            <input type="file" name="anh_chinh" id="fileInput" class="d-none" accept="image/*">
                            <div id="uploaded-files"></div>
                            <p class="fw-bolder mt-2 text-center">Ảnh chính</p>

                            <button type="submit" class="btn btn-primary w-100 mt-3 d-xl-none">Lưu thay đổi</button>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                                <?php $__currentLoopData = $chitiets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="fileInput<?php echo e($index); ?>" style="cursor: pointer;">
                                        <img id="previewImage<?php echo e($index); ?>" src="<?php echo e(asset('admin/images/products/' . $chitiet->hinh_anh)); ?>"
                                            alt="Ảnh sản phẩm" class="img-fluid rounded bg-light preview-image"
                                            style="width: 100%; object-fit: cover;">
                                    </label>
                            
                                    <input type="file" name="hinh_anh[<?php echo e($index); ?>]" id="fileInput<?php echo e($index); ?>"
                                        class="d-none file-input" accept="image/*">
                            
                                    <input type="hidden" name="old_images[]" value="<?php echo e($chitiet->hinh_anh); ?>">
                            
                                    <p class="fw-bolder mt-2 text-center">Ảnh phụ <?php echo e($index + 1); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                
                                <?php if(count($chitiets) < 4): ?>
                                    <label for="addImage" class="btn btn-secondary mt-3 w-100">+ Thêm ảnh phụ mới</label>
                                    <input type="file" name="hinh_anh_new[]" id="addImage" class="d-none" multiple accept="image/*">
                                <?php endif; ?>
                            
                                <button type="submit" class="btn btn-primary w-100 mt-3 d-xl-none">Lưu thay đổi</button>
                            </div>
                    </div>
                </div>
                

                <!-- Right Column -->
                <div class="col-xl-9 col-lg-8">
                    <div class="card mb-3">
                        <div class="card-header"><h4 class="card-title">Product Information</h4></div>
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-lg-6">
                                    <label for="ten_san_pham_vi" class="form-label">Tên sản phẩm</label>
                                    <input type="text" name="ten_san_pham_vi" class="form-control" placeholder="Tên sản phẩm" value="<?php echo e($product->ten_san_pham_vi); ?>">
                                </div>
                                <div class="col-lg-6">
                                    <label for="ten_san_pham_en" class="form-label">Product Name (English)</label>
                                    <input type="text" name="ten_san_pham_en" class="form-control" placeholder="Tên sản phẩm English" value="<?php echo e($product->ten_san_pham_en); ?>">
                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-lg-6">
                                    <label for="id_danh_muc" class="form-label">Product Categories</label>
                                    <select name="id_danh_muc" class="form-control">
                                        <?php $__currentLoopData = $catalogies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalogie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($catalogie->id); ?>" <?php echo e($product->id_danh_muc == $catalogie->id ? 'selected' : ''); ?>><?php echo e($catalogie->ten_danh_muc_vi); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-6">
                                    <label for="slug" class="form-label">Slug</label>
                                    <input type="text" name="slug" class="form-control" value="<?php echo e($product->slug); ?>">
                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-lg-4">
                                    <label for="so_luong" class="form-label">Số lượng</label>
                                    <input type="number" name="so_luong" class="form-control" value="<?php echo e($product->so_luong); ?>">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="mo_ta_vi" class="form-label">Mô tả ngắn</label>
                                <textarea class="form-control" name="mo_ta_vi" rows="2"><?php echo e($product->mo_ta_ngan_vi); ?></textarea>
                                <textarea class="form-control mt-2" name="mo_ta_en" rows="2"><?php echo e($product->mo_ta_ngan_en); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Mô tả</label>
                                <textarea class="form-control" id="mo_ta_vi" name="mo_ta_vi" rows="6"><?php echo e($product->mo_ta_vi); ?></textarea>
                                <label class="form-label mt-1">Mô tả English</label>
                                <textarea class="form-control mt-2" id="mo_ta_en" name="mo_ta_en" rows="6"><?php echo e($product->mo_ta_en); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-3">
                        <div class="card-header"><h4 class="card-title">Pricing Details</h4></div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4">
                                    <label for="gia_goc_vi" class="form-label">Giá VND</label>
                                    <input type="number" name="gia_goc_vi" class="form-control" value="<?php echo e($product->gia_goc_vi); ?>">
                                </div>
                                <div class="col-lg-4">
                                    <label for="gia_goc_en" class="form-label">Giá USD</label>
                                    <input type="number" name="gia_goc_en" class="form-control" value="<?php echo e($product->gia_goc_en); ?>">
                                </div>
                                <div class="col-lg-4">
                                    <label for="discount" class="form-label">Discount (%)</label>
                                    <input type="number" name="discount" class="form-control" value="<?php echo e($product->discount ?? 0); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Submit buttons -->
                    <div class="text-end mb-5">
                        <button type="reset" class="btn btn-outline-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('fileInput').addEventListener('change', function(event) {
        const file = event.target.files[0];
        const preview = document.getElementById('previewImage');

        if (file && preview) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    document.querySelectorAll('.file-input').forEach((input, index) => {
        input.addEventListener('change', function (event) {
            const file = event.target.files[0];
            const preview = document.getElementById('previewImage' + index);

            if (file && preview) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    });

    ClassicEditor.create(document.querySelector('#mo_ta_vi')).catch(error => console.error(error));
    ClassicEditor.create(document.querySelector('#mo_ta_en')).catch(error => console.error(error));
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\goldenbox\goldenbox2\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>