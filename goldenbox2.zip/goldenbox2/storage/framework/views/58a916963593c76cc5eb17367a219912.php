<?php $__env->startSection('title', 'Trang đăng nhập'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('content'); ?>

    <div class="container d-flex justify-content-center align-item-center">

        <form action="<?php echo e(route('admin.login')); ?>" method="post" enctype="multipart/form-data" class="col-lg-6 col-md-12">
            <?php echo csrf_field(); ?>
            <h2 class="text-center">Đăng Nhập</h2>
            <div class="mb-3">
                <label class="form-label">Email đăng nhập</label>
                <input type="email" class="form-control" name="email">
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="mb-3">
                <label class="form-label">Mật khẩu</label>
                <input type="text" class="form-control" name="password">
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary">Đăng Nhập</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\goldenbox\goldenbox2\resources\views/client/login.blade.php ENDPATH**/ ?>