


<?php $__env->startSection('title', 'Trang admin'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content">

    <!-- Start Container Fluid -->
    <div class="container-xxl">

        <div class="row">
             <div class="col-lg-4">
                  <div class="card">
                       <div class="card-body">
                            <!-- Crossfade -->
                            <div class="row mb-3">
                            <div class="col-12">
                              <img id="mainImage" src="<?php echo e(asset('admin/images/products/'.$product->anh_chinh)); ?>" class="img-fluid w-100 rounded" alt="Ảnh chính">
                            </div>
                          </div>
                        
                          <!-- Row 2: 4 ảnh phụ -->
                          <div class="row text-center">
                              <?php $__currentLoopData = $chitiets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div class="col-3">
                                        <img src="<?php echo e(asset('admin/images/products/'.$chitiet->hinh_anh)); ?>" class="img-fluid img-thumbnail" alt="Ảnh phụ 1" onclick="changeMainImage(this)">
                                   </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                       </div>
                  </div>
             </div>
             <div class="col-lg-8">
                  <div class="card">
                       <div class="card-body">
                            <h4 class="badge bg-success text-light fs-14 py-1 px-2">Hàng mới</h4>
                            <p class="mb-1">
                                 <a href="#!" class="fs-24 text-dark fw-medium"><?php echo e($product->ten_san_pham_vi); ?></a>
                            </p>
                            <div class="d-flex gap-2 align-items-center">
                                 <ul class="d-flex text-warning m-0 fs-20  list-unstyled">
                                      <li>
                                           <i class="bx bxs-star"></i>
                                      </li>
                                      <li>
                                           <i class="bx bxs-star"></i>
                                      </li>
                                      <li>
                                           <i class="bx bxs-star"></i>
                                      </li>
                                      <li>
                                           <i class="bx bxs-star"></i>
                                      </li>
                                      <li>
                                           <i class="bx bxs-star-half"></i>
                                      </li>
                                 </ul>
                                 <p class="mb-0 fw-medium fs-18 text-dark">4.5 <span class="text-muted fs-13">(55 Review)</span></p>
                            </div>
                            <h2 class="fw-medium my-3"><?php echo e($product->gia_goc_vn); ?>  <!--<span class="fs-16 text-decoration-line-through">$100.00</span><small class="text-danger ms-2">(30%Off)</small>--> </h2>

                            <div class="quantity mt-4">
                                 <h4 class="text-dark fw-medium mt-3">Số lượng</h4>
                                 <div class="input-step border bg-body-secondary p-1 mt-1 rounded d-inline-flex overflow-visible">
                                      <p><?php echo e($product->so_luong); ?></p>
                                 </div>
                            </div>
                            <h4 class="text-dark fw-medium">Description Short:</h4> <?php echo e($product->mo_ta_ngan_vi); ?>

                                   <?php echo html_entity_decode($product->mo_ta_ngan_vn); ?>

                            <h4 class="text-dark fw-medium mt-3">Description</h4>
                            <div class="d-flex align-items-center mt-2">
                                 <i class="bx bxs-bookmarks text-success me-3 fs-20 mt-1"></i>
                                 <?php echo html_entity_decode($product->mo_ta_vi); ?>

                            </div>
                            
                       </div>
                  </div>
             </div>
        </div>
     </div>
</div>
    <!-- End Container Fluid -->
    <script>
     function changeMainImage(element) {
       const mainImage = document.getElementById('mainImage');
       mainImage.src = element.src;
     }
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\goldenbox\goldenbox2\resources\views/admin/products/detail.blade.php ENDPATH**/ ?>