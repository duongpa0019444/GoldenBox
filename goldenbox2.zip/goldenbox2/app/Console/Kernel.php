<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        // Đăng ký command tùy chỉnh ở đây nếu muốn
        \App\Console\Commands\CleanUpTempImages::class,
    ];

    protected function schedule(Schedule $schedule): void
    {
        // Chạy command mỗi phút
        $schedule->command('app:clean-up-temp-images')->everyMinute();
    }

    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
