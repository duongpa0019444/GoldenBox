<?php

namespace App\Console\Commands;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use League\CommonMark\Extension\CommonMark\Node\Inline\Strong;

class CleanUpTempImages extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:clean-up-temp-images';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
        {
            $this->info('Đã chạy command xóa ảnh tạm!');
            
            $files = Storage::files('temp');
            foreach ($files as $file) {
                Storage::delete($file);
                $this->info("Đã xóa: {$file}");
            }
        
            $this->info('Dọn xong ảnh rác!');
        
    }
  

}
